<?php
include('config.php');
include('functions.php');
?>
<html>
	<head>
		<title>
		
		</title>
	</head>
	<div>
		<h1>Expense</h1>
	</div>