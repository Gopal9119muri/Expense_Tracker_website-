<?php
// Include header and necessary functions
include('header.php');
checkUser();
userArea();

// Check if delete request is made
if(isset($_GET['type']) && $_GET['type']=='delete' && isset($_GET['id']) && $_GET['id']>0){
    $id = get_safe_value($_GET['id']);
    $delete_query = "DELETE FROM expense WHERE id=$id";
    if (mysqli_query($con, $delete_query)) {
        echo "<br/>Data deleted<br/>";
    } else {
        echo "<br/>Error deleting data: " . mysqli_error($con) . "<br/>";
    }
}

// Fetch expenses from database
$query = "SELECT expense.*, category.name 
          FROM expense, category  
          WHERE expense.category_id = category.id 
            AND expense.added_by = '".$_SESSION['UID']."' 
          ORDER BY expense.expense_date ASC";
$res = mysqli_query($con, $query);

// Check if the query executed successfully
if (!$res) {
    echo "<br/>Error fetching data: " . mysqli_error($con) . "<br/>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Expense Tracker</title>
   <style>
      .centered {
         display: flex;
         flex-direction: column;
         justify-content: center;
         align-items: center;
         height: 100vh; /* Full viewport height */
         text-align: center;
      }
      .main-content {
         margin-top: 20px; /* Adjust as needed */
      }
      .add-expense-box {
         border: 1px solid #ccc;
         padding: 20px;
         border-radius: 10px;
         box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
         margin-top: 20px;
      }
      .add-expense-link {
         display: inline-block;
         padding: 10px 20px;
         background-color: #007bff;
         color: #fff;
         text-decoration: none;
         border-radius: 5px;
         margin-top: 10px;
      }
      .add-expense-link:hover {
         background-color: #0056b3;
      }
   </style>
</head>
<body>
<?php
if (mysqli_num_rows($res) > 0) {
?>
<script>
   setTitle("Expense");
   selectLink('expense_link');
</script>
<div class="main-content">
   <div class="section__content section__content--p30">
      <div class="container-fluid">
         <div class="row">
            <div class="col-lg-12">
               <h2>Expense</h2>
               <a href="manage_expense.php">Add Expense</a>
               <br/><br/>
               <div class="table-responsive table--no-card m-b-30">
                  <table class="table table-borderless table-striped table-earning">
                     <thead>
                        <tr>
                           <th>ID</th>
                           <th>Category</th>
                           <th>Item</th>
                           <th>Price</th>
                           <th>Expense Date</th>
                           <th></th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php while($row = mysqli_fetch_assoc($res)){ ?>
                        <tr>
                           <td><?php echo $row['id']; ?></td>
                           <td><?php echo $row['name']; ?></td>
                           <td><?php echo $row['item']; ?></td>
                           <td><?php echo $row['price']; ?></td>
                           <td><?php echo $row['expense_date']; ?></td>
                           <td>
                              <a href="manage_expense.php?id=<?php echo $row['id']; ?>">Edit</a>&nbsp;
                              <a href="javascript:void(0)" onclick="delete_confir('<?php echo $row['id']; ?>', 'expense.php')">Delete</a>
                           </td>
                        </tr>
                        <?php } ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php
} else {
?>
<div class="centered">
   <h1>No data Found</h1>
   <div class="add-expense-box">
      <a href="manage_expense.php" class="add-expense-link">Add Expense</a>
   </div>
</div>
<?php
}
include('footer.php');
?>
</body>
</html>
