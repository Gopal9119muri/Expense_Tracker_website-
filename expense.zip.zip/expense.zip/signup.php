<?php
include('config.php');
include('functions.php');
$msg = "";
if (isset($_POST['signup'])) {
    $username = get_safe_value($_POST['username']);
    $password = get_safe_value($_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    $res = mysqli_query($con, "select * from users where username='$username'");
    if (mysqli_num_rows($res) > 0) {
        $msg = "Username already exists";
    } else {
        $query = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashed_password', 'User')";
        mysqli_query($con, $query);
        $msg = "User created successfully. Please log in.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Sign Up">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="Sign Up">
    <title>Sign Up</title>
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <link href="css/theme.css" rel="stylesheet" media="all">
    <style>
        .success-message {
            display: none;
            color: green;
            font-weight: bold;
            font-size: 18px;
            margin-top: 20px;
        }
        .success-message.show {
            display: block;
            animation: fadeIn 1s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .back-button {
            margin-top: 20px;
            display: inline-block;
            padding: 10px 20px;
            background-color: #5cb85c;
            color: #fff;
            text-align: center;
            border-radius: 5px;
            text-decoration: none;
        }
        .back-button:hover {
            background-color: #4cae4c;
        }
    </style>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="#">
                                <img src="images/icon/logo.png" alt="CoolAdmin">
                            </a>
                        </div>
                        <div class="login-form">
                            <form action="" method="post">
                                <div class="form-group">
                                    <label>Username</label>
                                    <input class="au-input au-input--full" type="text" name="username" placeholder="Username" required>
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="au-input au-input--full" type="password" name="password" placeholder="Password" required>
                                </div>
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit" name='signup'>Sign Up</button>
                            </form>
                            <div id="msg" class="success-message <?php echo $msg === "User created successfully. Please log in." ? 'show' : '' ?>">✓ <?php echo $msg ?></div>
                            <?php if ($msg === "User created successfully. Please log in.") { ?>
                                <a href="index.php" class="back-button">Back to Login</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
